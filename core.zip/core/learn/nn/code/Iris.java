package learn.nn.code;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import learn.nn.core.Example;
import learn.nn.core.MultiLayerFeedForwardNeuralNetwork;

public class Iris {
	
	public static List<Example> readFile(String fileName) throws IOException{
		List<Example> examples=new ArrayList<Example>();
		
		BufferedReader br=new BufferedReader(new FileReader(fileName));
		String line;
		while((line=br.readLine())!=null) {
			String[] temp=line.split(",");
			//intput output
			Example ex=new Example(4, 3);
			   if(temp[0].isEmpty()){
	                break;
	            }
			double[] inputs= {Double.parseDouble(temp[0]),
							  Double.parseDouble(temp[1]),
							  Double.parseDouble(temp[2]),
							  Double.parseDouble(temp[3])
					};
			//3 kinds of flowers
			double[] outputs= {0.0,0.0,0.0};
			if(temp[4].equals("Iris-setosa")) {
				outputs[0]=1.0;
			}else if(temp[4].equals("Iris-versicolor")) {
				outputs[1]=1.0;
			}else if(temp[4].equals("Iris-virginica")) {
				outputs[2]=1.0;
			}
			ex.inputs=inputs;
			ex.outputs=outputs;
			examples.add(ex);
		
		}

		br.close();
		return examples;
	}
	
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		int epochs=1000;
		double alpha=0.1;
		String path="learn/nn/examples/iris.data.txt";
		List<Example> examples=readFile(path);
        System.out.println("IrisNN: reading data from "+path);

        System.out.println("Training for " + epochs + " epochs with alpha = " + alpha);
        //values suggested from the project description
 
        MultiLayerFeedForwardNeuralNetwork Multi_NN=new MultiLayerFeedForwardNeuralNetwork(4,7,3);
        Multi_NN.train(examples, epochs, alpha);
        Multi_NN.dump();
        double accuracy1 = Multi_NN.test(examples);
        System.out.println("Overall accuracy=" + accuracy1);
        System.out.println();


		//K-folds
		int k=10;
        System.out.println("k-Fold Cross-Validation: k="+k);
        double accuracy2= Multi_NN.kFoldCrossValidate(examples, k, epochs, alpha);
        System.out.println("Average accuracy=" + accuracy2);
        System.out.println();

        
        //Varing Number
        System.out.println("Learning Curve testing on all training data");
        System.out.println("EPOCHS\tACCURACY");

        for(int i=100; i<=3000; i+=100) {
        	Multi_NN.train(examples, i, alpha);
        	double accuracy3=Multi_NN.test(examples);
            System.out.println(i+"\t"+ accuracy3);

        }

		

	}

	
}








