package learn.lc.code;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import learn.lc.core.DecayingLearningRateSchedule;
import learn.lc.core.Example;
import learn.lc.core.LogisticClassifier;

public class Logistic {
	public static List<Example> readFile(String fileName) throws IOException{
		List<Example> examples=new ArrayList<Example>();
		
		BufferedReader br=new BufferedReader(new FileReader(fileName));
		String line;
		while((line=br.readLine())!=null) {
			String[] temp=line.split(",");
			int n=temp.length;
			Example ex=new Example(n);
			//initialization of ex
			ex.output=Double.parseDouble(temp[n-1]);
			ex.inputs[0]=1.0;
			for(int i=1;i<temp.length;i++) {
				ex.inputs[i]=Double.parseDouble(temp[i-1]);
			}
			examples.add(ex);
		}

		br.close();
		return examples;
	}
	
	
	public static void logisticClassifier(String fileName, int step, double alpha) throws IOException {

		List<Example> examples=readFile(fileName);
		
		int ninputs=examples.get(0).inputs.length;
		
		LogisticClassifier lc=new LogisticClassifier(ninputs);

		
		if(alpha>0) {
			lc.train(examples, step, alpha,"Logistic");
		}else {
			lc.train(examples, step, new DecayingLearningRateSchedule(),"Logistic");
		}

		
	}
	
	public static void run(String command, int step, double alpha) throws IOException {
		String path="";
		if(command.equals("EarthquakeClean")) {
			path="learn/lc/examples/earthquake-clean.data.txt";
		}else if(command.equals("EarthquakeNoisy")) {
			path="learn/lc/examples/earthquake-noisy.data.txt";
		}else if(command.equals("EarthquakeNoisyDecaying")) {
			path="learn/lc/examples/earthquake-noisy.data.txt";
		}else if(command.equals("HouseVotes")) {
			path="learn/lc/examples/house-votes-84.data.num.txt";
		}
		System.out.println("path: "+path);
		logisticClassifier(path, step, alpha);
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String command=args[0];
		//default values
		int step=10000;
		double alpha=0.05;
		if(command.equals("EarthquakeNoisyDecaying")) {
			//suggested level from AIMA
			step=100000;
			alpha=-1;
		}
		run(command, step, alpha);
	}

}
